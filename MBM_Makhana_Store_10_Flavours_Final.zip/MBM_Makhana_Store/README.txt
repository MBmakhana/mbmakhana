MBM MAKHANA STORE - FINAL COMPLETE WEBSITE

10 MAKHANA FLAVOURS ADDED
1. Classic Salted
2. Classic Salty & Pepper
3. Pudina Masala
4. Tangy Tomato
5. Cheese & Herb
6. Peri Peri
7. Chatpata Masala
8. Cream & Onion
9. Tandoori Masala
10. Roasted & Seasoned

Each flavour has a Direct WhatsApp Order button.

Business:
MBM Makhana Store
Founder: Harsh Kumar
Manufacturing Address: Sultanpur, Mokama, Bihar, India
Mobile / WhatsApp: +91 7541094030
Email: mbmmakhana75@gmail.com

Open index.html in a browser. Keep all files in the same folder.
